-- =====================================================================
-- Teacher Attendance Management System — Initial schema (Supabase/Postgres)
-- Run this in Supabase SQL Editor, or via psql against DATABASE_URL.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto"; -- for gen_random_uuid()

-- ---------------------------------------------------------------------
-- teachers (also stores the admin user, role = 'admin')
-- ---------------------------------------------------------------------
CREATE TYPE user_role AS ENUM ('admin', 'teacher');

CREATE TABLE IF NOT EXISTS teachers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(150) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    phone           VARCHAR(20),
    department      VARCHAR(100),
    designation     VARCHAR(100),
    password_hash   VARCHAR(255) NOT NULL,
    role            user_role NOT NULL DEFAULT 'teacher',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_teachers_email ON teachers(email);
CREATE INDEX IF NOT EXISTS idx_teachers_department ON teachers(department);

-- ---------------------------------------------------------------------
-- attendance
-- ---------------------------------------------------------------------
CREATE TYPE attendance_status AS ENUM ('present', 'late', 'absent');

CREATE TABLE IF NOT EXISTS attendance (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id            UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
    date                  DATE NOT NULL,
    check_in_time         TIMESTAMPTZ,
    check_out_time        TIMESTAMPTZ,
    working_hours         DOUBLE PRECISION,
    check_in_latitude     DOUBLE PRECISION,
    check_in_longitude    DOUBLE PRECISION,
    check_out_latitude    DOUBLE PRECISION,
    check_out_longitude   DOUBLE PRECISION,
    status                attendance_status NOT NULL DEFAULT 'present',
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_teacher_date UNIQUE (teacher_id, date)
);

CREATE INDEX IF NOT EXISTS idx_attendance_teacher_id ON attendance(teacher_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);

-- ---------------------------------------------------------------------
-- school_settings (single row, id = 1)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS school_settings (
    id                  INTEGER PRIMARY KEY DEFAULT 1,
    school_name         VARCHAR(150) NOT NULL DEFAULT 'My School',
    latitude            DOUBLE PRECISION NOT NULL,
    longitude           DOUBLE PRECISION NOT NULL,
    radius_meters       INTEGER NOT NULL DEFAULT 75,
    school_start_time   TIME NOT NULL DEFAULT '08:45:00',
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT single_row CHECK (id = 1)
);

-- Default geofence: AECS Magnolia Maaruti Public School (from provided Maps link)
INSERT INTO school_settings (id, school_name, latitude, longitude, radius_meters, school_start_time)
VALUES (1, 'AECS Magnolia Maaruti Public School', 12.8845715, 77.5969675, 75, '08:45:00')
ON CONFLICT (id) DO NOTHING;
