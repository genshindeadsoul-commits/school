"""
FastAPI application entrypoint.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import auth, teachers, attendance, reports, dashboard, settings as settings_router

app = FastAPI(
    title="Teacher Attendance Management System",
    description="GPS geofenced attendance system for a single school.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_ORIGIN, "http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(teachers.router)
app.include_router(attendance.router)
app.include_router(reports.router)
app.include_router(dashboard.router)
app.include_router(settings_router.router)


@app.get("/")
def root():
    return {"status": "ok", "service": "Teacher Attendance Management System API"}


@app.get("/health")
def health():
    return {"status": "healthy"}
