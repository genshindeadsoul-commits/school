"""
School-wide settings — geofence center/radius and the official start time
used to compute the 'late' status. Single-row table (id=1).
"""
from sqlalchemy import Column, Integer, String, Float, Time, DateTime
from sqlalchemy.sql import func

from app.database import Base


class SchoolSettings(Base):
    __tablename__ = "school_settings"

    id = Column(Integer, primary_key=True, default=1)
    school_name = Column(String(150), nullable=False, default="My School")
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    radius_meters = Column(Integer, nullable=False, default=75)
    school_start_time = Column(Time, nullable=False)  # e.g. 08:45:00, used for late calc

    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
