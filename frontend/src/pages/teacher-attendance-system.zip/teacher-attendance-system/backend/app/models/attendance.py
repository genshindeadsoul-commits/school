"""
Attendance model — one row per teacher per calendar day.
"""
import enum
import uuid
from sqlalchemy import Column, String, Date, Time, Float, DateTime, ForeignKey, Enum, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.database import Base


class AttendanceStatus(str, enum.Enum):
    present = "present"
    late = "late"
    absent = "absent"


class Attendance(Base):
    __tablename__ = "attendance"
    __table_args__ = (
        UniqueConstraint("teacher_id", "date", name="uq_teacher_date"),
    )

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    teacher_id = Column(UUID(as_uuid=True), ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False, index=True)
    date = Column(Date, nullable=False, index=True)

    check_in_time = Column(DateTime(timezone=True), nullable=True)
    check_out_time = Column(DateTime(timezone=True), nullable=True)
    working_hours = Column(Float, nullable=True)  # computed on checkout, in hours

    check_in_latitude = Column(Float, nullable=True)
    check_in_longitude = Column(Float, nullable=True)
    check_out_latitude = Column(Float, nullable=True)
    check_out_longitude = Column(Float, nullable=True)

    status = Column(Enum(AttendanceStatus), nullable=False, default=AttendanceStatus.present)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    teacher = relationship("Teacher", backref="attendance_records")
