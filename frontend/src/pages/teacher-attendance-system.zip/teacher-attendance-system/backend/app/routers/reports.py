"""
Admin reporting: today's attendance (all teachers), monthly view, individual
teacher report, and CSV/Excel export. Also covers 'daily' and 'weekly' by
passing an explicit date range.
"""
from datetime import date as date_type, timedelta
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
import io

from sqlalchemy.orm import Session

from app.database import get_db
from app.models.attendance import Attendance
from app.models.teacher import Teacher, UserRole
from app.schemas.attendance import AttendanceOut, AttendanceListResponse
from app.services.export_service import to_csv_bytes, to_excel_bytes
from app.utils.deps import require_admin

router = APIRouter(prefix="/api/reports", tags=["Reports"], dependencies=[Depends(require_admin)])


def _serialize(records) -> list[AttendanceOut]:
    return [
        AttendanceOut(
            id=r.id, teacher_id=r.teacher_id, teacher_name=r.teacher.name, date=r.date,
            check_in_time=r.check_in_time, check_out_time=r.check_out_time,
            working_hours=r.working_hours, status=r.status.value,
        )
        for r in records
    ]


def _query_range(
    db: Session, start: date_type, end: date_type, teacher_id: Optional[UUID] = None
):
    query = db.query(Attendance).filter(Attendance.date >= start, Attendance.date <= end)
    if teacher_id:
        query = query.filter(Attendance.teacher_id == teacher_id)
    return query.order_by(Attendance.date.desc())


@router.get("/today", response_model=AttendanceListResponse)
def today_report(db: Session = Depends(get_db)):
    today = date_type.today()
    records = _query_range(db, today, today).all()
    return AttendanceListResponse(total=len(records), page=1, page_size=len(records) or 1, items=_serialize(records))


@router.get("/range", response_model=AttendanceListResponse)
def range_report(
    start_date: date_type = Query(...),
    end_date: date_type = Query(...),
    teacher_id: Optional[UUID] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
):
    """Generic report used for daily (start==end), weekly, monthly, or custom ranges."""
    query = _query_range(db, start_date, end_date, teacher_id)
    total = query.count()
    records = query.offset((page - 1) * page_size).limit(page_size).all()
    return AttendanceListResponse(total=total, page=page, page_size=page_size, items=_serialize(records))


@router.get("/teacher/{teacher_id}", response_model=AttendanceListResponse)
def teacher_report(
    teacher_id: UUID,
    month: Optional[int] = Query(None, ge=1, le=12),
    year: Optional[int] = Query(None, ge=2000, le=2100),
    db: Session = Depends(get_db),
):
    query = db.query(Attendance).filter(Attendance.teacher_id == teacher_id)
    if month and year:
        start = date_type(year, month, 1)
        end = date_type(year + (1 if month == 12 else 0), 1 if month == 12 else month + 1, 1) - timedelta(days=1)
        query = query.filter(Attendance.date >= start, Attendance.date <= end)
    records = query.order_by(Attendance.date.desc()).all()
    return AttendanceListResponse(total=len(records), page=1, page_size=len(records) or 1, items=_serialize(records))


@router.get("/export")
def export_report(
    start_date: date_type = Query(...),
    end_date: date_type = Query(...),
    teacher_id: Optional[UUID] = None,
    format: str = Query("csv", pattern="^(csv|excel)$"),
    db: Session = Depends(get_db),
):
    records = _query_range(db, start_date, end_date, teacher_id).all()
    rows = [
        {
            "Teacher": r.teacher.name,
            "Email": r.teacher.email,
            "Department": r.teacher.department or "",
            "Date": r.date.isoformat(),
            "Check In": r.check_in_time.strftime("%H:%M:%S") if r.check_in_time else "",
            "Check Out": r.check_out_time.strftime("%H:%M:%S") if r.check_out_time else "",
            "Working Hours": r.working_hours or "",
            "Status": r.status.value,
        }
        for r in records
    ]
    if not rows:
        rows = [{"Teacher": "", "Email": "", "Department": "", "Date": "", "Check In": "", "Check Out": "", "Working Hours": "", "Status": "No records found"}]

    filename = f"attendance_{start_date}_{end_date}.{'csv' if format == 'csv' else 'xlsx'}"
    if format == "csv":
        content = to_csv_bytes(rows)
        media_type = "text/csv"
    else:
        content = to_excel_bytes(rows)
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    return StreamingResponse(
        io.BytesIO(content),
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
