"""
Attendance routes for the logged-in teacher: check-in, check-out, today's
status, own history/calendar. Admin-wide views live in reports.py.
"""
from datetime import date as date_type
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.teacher import Teacher
from app.models.attendance import Attendance
from app.schemas.attendance import (
    CheckInRequest,
    CheckOutRequest,
    AttendanceOut,
    AttendanceListResponse,
    TodayStatusOut,
)
from app.services import attendance_service
from app.utils.deps import get_current_user

router = APIRouter(prefix="/api/attendance", tags=["Attendance"])


@router.post("/check-in", response_model=AttendanceOut)
def check_in(
    payload: CheckInRequest,
    current_user: Teacher = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    record = attendance_service.check_in(db, current_user.id, payload.latitude, payload.longitude)
    return AttendanceOut(
        id=record.id, teacher_id=record.teacher_id, teacher_name=current_user.name,
        date=record.date, check_in_time=record.check_in_time, check_out_time=record.check_out_time,
        working_hours=record.working_hours, status=record.status.value,
    )


@router.post("/check-out", response_model=AttendanceOut)
def check_out(
    payload: CheckOutRequest,
    current_user: Teacher = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    record = attendance_service.check_out(db, current_user.id, payload.latitude, payload.longitude)
    return AttendanceOut(
        id=record.id, teacher_id=record.teacher_id, teacher_name=current_user.name,
        date=record.date, check_in_time=record.check_in_time, check_out_time=record.check_out_time,
        working_hours=record.working_hours, status=record.status.value,
    )


@router.get("/today", response_model=TodayStatusOut)
def today_status(current_user: Teacher = Depends(get_current_user), db: Session = Depends(get_db)):
    record = (
        db.query(Attendance)
        .filter(Attendance.teacher_id == current_user.id, Attendance.date == date_type.today())
        .first()
    )
    if not record:
        return TodayStatusOut(checked_in=False, checked_out=False)
    return TodayStatusOut(
        checked_in=bool(record.check_in_time),
        checked_out=bool(record.check_out_time),
        check_in_time=record.check_in_time,
        check_out_time=record.check_out_time,
        working_hours=record.working_hours,
        status=record.status.value,
    )


@router.get("/history", response_model=AttendanceListResponse)
def my_history(
    month: Optional[int] = Query(None, ge=1, le=12),
    year: Optional[int] = Query(None, ge=2000, le=2100),
    page: int = Query(1, ge=1),
    page_size: int = Query(31, ge=1, le=100),
    current_user: Teacher = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(Attendance).filter(Attendance.teacher_id == current_user.id)
    if month and year:
        query = query.filter(
            Attendance.date >= date_type(year, month, 1),
            Attendance.date < date_type(year + (1 if month == 12 else 0), 1 if month == 12 else month + 1, 1),
        )
    total = query.count()
    items = (
        query.order_by(Attendance.date.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return AttendanceListResponse(
        total=total, page=page, page_size=page_size,
        items=[
            AttendanceOut(
                id=r.id, teacher_id=r.teacher_id, teacher_name=current_user.name, date=r.date,
                check_in_time=r.check_in_time, check_out_time=r.check_out_time,
                working_hours=r.working_hours, status=r.status.value,
            ) for r in items
        ],
    )
