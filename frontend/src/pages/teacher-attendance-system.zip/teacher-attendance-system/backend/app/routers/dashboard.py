"""
Dashboard summary endpoint for admin (aggregate counts + recent check-ins).
"""
from datetime import date as date_type

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.teacher import Teacher, UserRole
from app.models.attendance import Attendance, AttendanceStatus
from app.schemas.dashboard import AdminDashboardOut
from app.schemas.attendance import AttendanceOut
from app.utils.deps import require_admin

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"], dependencies=[Depends(require_admin)])


@router.get("/admin", response_model=AdminDashboardOut)
def admin_dashboard(db: Session = Depends(get_db)):
    total_teachers = db.query(Teacher).filter(Teacher.role == UserRole.teacher, Teacher.is_active == True).count()  # noqa: E712

    today = date_type.today()
    today_records = db.query(Attendance).filter(Attendance.date == today).all()

    present_today = sum(1 for r in today_records if r.status in (AttendanceStatus.present, AttendanceStatus.late))
    late_today = sum(1 for r in today_records if r.status == AttendanceStatus.late)
    absent_today = max(total_teachers - present_today, 0)

    attendance_percentage = round((present_today / total_teachers) * 100, 1) if total_teachers else 0.0

    recent = (
        db.query(Attendance)
        .filter(Attendance.date == today, Attendance.check_in_time.isnot(None))
        .order_by(Attendance.check_in_time.desc())
        .limit(10)
        .all()
    )
    recent_out = [
        AttendanceOut(
            id=r.id, teacher_id=r.teacher_id, teacher_name=r.teacher.name, date=r.date,
            check_in_time=r.check_in_time, check_out_time=r.check_out_time,
            working_hours=r.working_hours, status=r.status.value,
        )
        for r in recent
    ]

    return AdminDashboardOut(
        total_teachers=total_teachers,
        present_today=present_today,
        absent_today=absent_today,
        late_today=late_today,
        attendance_percentage=attendance_percentage,
        recent_checkins=recent_out,
    )
