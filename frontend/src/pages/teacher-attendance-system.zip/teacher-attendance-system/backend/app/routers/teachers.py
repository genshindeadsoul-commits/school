"""
Teacher CRUD — admin only. Includes search, pagination, activate/deactivate,
and password reset.
"""
from uuid import UUID
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.teacher import Teacher, UserRole
from app.schemas.teacher import TeacherCreate, TeacherUpdate, TeacherOut, TeacherListResponse
from app.schemas.auth import ResetPasswordRequest
from app.utils.security import hash_password
from app.utils.deps import require_admin

router = APIRouter(prefix="/api/teachers", tags=["Teachers"], dependencies=[Depends(require_admin)])


@router.get("", response_model=TeacherListResponse)
def list_teachers(
    search: Optional[str] = Query(None, description="Search by name or email"),
    department: Optional[str] = None,
    is_active: Optional[bool] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    db: Session = Depends(get_db),
):
    query = db.query(Teacher).filter(Teacher.role == UserRole.teacher)

    if search:
        like = f"%{search}%"
        query = query.filter(or_(Teacher.name.ilike(like), Teacher.email.ilike(like)))
    if department:
        query = query.filter(Teacher.department == department)
    if is_active is not None:
        query = query.filter(Teacher.is_active == is_active)

    total = query.count()
    items = (
        query.order_by(Teacher.name)
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return TeacherListResponse(total=total, page=page, page_size=page_size, items=items)


@router.post("", response_model=TeacherOut, status_code=201)
def create_teacher(payload: TeacherCreate, db: Session = Depends(get_db)):
    if db.query(Teacher).filter(Teacher.email == payload.email).first():
        raise HTTPException(status_code=400, detail="A teacher with this email already exists")

    teacher = Teacher(
        name=payload.name,
        email=payload.email,
        phone=payload.phone,
        department=payload.department,
        designation=payload.designation,
        password_hash=hash_password(payload.password),
        role=UserRole.teacher,
        is_active=True,
    )
    db.add(teacher)
    db.commit()
    db.refresh(teacher)
    return teacher


@router.get("/{teacher_id}", response_model=TeacherOut)
def get_teacher(teacher_id: UUID, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    return teacher


@router.put("/{teacher_id}", response_model=TeacherOut)
def update_teacher(teacher_id: UUID, payload: TeacherUpdate, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")

    data = payload.model_dump(exclude_unset=True)
    if "email" in data and data["email"] != teacher.email:
        if db.query(Teacher).filter(Teacher.email == data["email"]).first():
            raise HTTPException(status_code=400, detail="A teacher with this email already exists")

    for field, value in data.items():
        setattr(teacher, field, value)

    db.commit()
    db.refresh(teacher)
    return teacher


@router.delete("/{teacher_id}", status_code=204)
def delete_teacher(teacher_id: UUID, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    db.delete(teacher)
    db.commit()
    return None


@router.patch("/{teacher_id}/status", response_model=TeacherOut)
def toggle_active_status(teacher_id: UUID, is_active: bool, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    teacher.is_active = is_active
    db.commit()
    db.refresh(teacher)
    return teacher


@router.post("/{teacher_id}/reset-password")
def reset_password(teacher_id: UUID, payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    teacher = db.query(Teacher).filter(Teacher.id == teacher_id).first()
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found")
    teacher.password_hash = hash_password(payload.new_password)
    db.commit()
    return {"message": "Password reset successfully"}
