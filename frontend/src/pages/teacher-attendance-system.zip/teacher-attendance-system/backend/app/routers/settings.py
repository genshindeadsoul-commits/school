"""
School settings (geofence center/radius, start time) — admin can view/update,
teachers can read (needed client-side to show map context / distance).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.settings import SchoolSettings
from app.schemas.settings import SchoolSettingsOut, SchoolSettingsUpdate
from app.utils.deps import get_current_user, require_admin

router = APIRouter(prefix="/api/settings", tags=["School Settings"])


@router.get("", response_model=SchoolSettingsOut)
def get_settings(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    return db.query(SchoolSettings).filter(SchoolSettings.id == 1).first()


@router.put("", response_model=SchoolSettingsOut, dependencies=[Depends(require_admin)])
def update_settings(payload: SchoolSettingsUpdate, db: Session = Depends(get_db)):
    settings_row = db.query(SchoolSettings).filter(SchoolSettings.id == 1).first()
    data = payload.model_dump(exclude_unset=True)
    for field, value in data.items():
        setattr(settings_row, field, value)
    db.commit()
    db.refresh(settings_row)
    return settings_row
