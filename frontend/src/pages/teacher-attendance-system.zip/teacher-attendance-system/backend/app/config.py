"""
Application configuration, loaded from environment variables (.env).
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str

    # JWT
    JWT_SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480  # 8 hours

    # CORS
    FRONTEND_ORIGIN: str = "http://localhost:5173"

    # Defaults used only by the seed script
    DEFAULT_SCHOOL_NAME: str = "My School"
    DEFAULT_SCHOOL_LAT: float = 12.8845715
    DEFAULT_SCHOOL_LNG: float = 77.5969675
    DEFAULT_GEOFENCE_RADIUS_METERS: int = 75
    DEFAULT_SCHOOL_START_TIME: str = "08:45:00"

    ADMIN_EMAIL: str = "admin@school.edu"
    ADMIN_PASSWORD: str = "Admin@12345"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
