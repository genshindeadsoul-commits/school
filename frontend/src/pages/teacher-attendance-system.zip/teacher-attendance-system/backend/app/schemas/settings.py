from datetime import time
from pydantic import BaseModel, Field


class SchoolSettingsOut(BaseModel):
    school_name: str
    latitude: float
    longitude: float
    radius_meters: int
    school_start_time: time

    model_config = {"from_attributes": True}


class SchoolSettingsUpdate(BaseModel):
    school_name: str | None = None
    latitude: float | None = Field(None, ge=-90, le=90)
    longitude: float | None = Field(None, ge=-180, le=180)
    radius_meters: int | None = Field(None, ge=10, le=2000)
    school_start_time: time | None = None
