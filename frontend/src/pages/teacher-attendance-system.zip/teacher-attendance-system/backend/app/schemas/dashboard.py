from pydantic import BaseModel
from app.schemas.attendance import AttendanceOut


class AdminDashboardOut(BaseModel):
    total_teachers: int
    present_today: int
    absent_today: int
    late_today: int
    attendance_percentage: float
    recent_checkins: list[AttendanceOut]
