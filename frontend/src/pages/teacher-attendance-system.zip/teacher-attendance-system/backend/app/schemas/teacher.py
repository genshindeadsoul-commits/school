from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, EmailStr, Field


class TeacherBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=150)
    email: EmailStr
    phone: Optional[str] = Field(None, max_length=20)
    department: Optional[str] = Field(None, max_length=100)
    designation: Optional[str] = Field(None, max_length=100)


class TeacherCreate(TeacherBase):
    password: str = Field(..., min_length=6)


class TeacherUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=150)
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    department: Optional[str] = None
    designation: Optional[str] = None


class TeacherOut(TeacherBase):
    id: UUID
    role: str
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class TeacherListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[TeacherOut]
