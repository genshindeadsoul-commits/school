from datetime import datetime, date as date_type
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, Field


class CheckInRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)


class CheckOutRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)


class AttendanceOut(BaseModel):
    id: UUID
    teacher_id: UUID
    teacher_name: Optional[str] = None
    date: date_type
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    working_hours: Optional[float] = None
    status: str

    model_config = {"from_attributes": True}


class AttendanceListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[AttendanceOut]


class TodayStatusOut(BaseModel):
    checked_in: bool
    checked_out: bool
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    working_hours: Optional[float] = None
    status: Optional[str] = None
