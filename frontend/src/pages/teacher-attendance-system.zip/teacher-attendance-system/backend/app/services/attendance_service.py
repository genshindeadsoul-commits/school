"""
Core attendance business logic: check-in, check-out, status/late computation,
working-hours calculation. All rules from the spec are enforced here so
routers stay thin.
"""
from datetime import datetime, date as date_type, timezone

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.attendance import Attendance, AttendanceStatus
from app.models.settings import SchoolSettings
from app.services.geofence import is_within_geofence


def get_school_settings(db: Session) -> SchoolSettings:
    settings_row = db.query(SchoolSettings).filter(SchoolSettings.id == 1).first()
    if not settings_row:
        raise HTTPException(status_code=500, detail="School settings not configured. Contact admin.")
    return settings_row


def check_in(db: Session, teacher_id, latitude: float, longitude: float) -> Attendance:
    school = get_school_settings(db)

    inside, distance = is_within_geofence(
        latitude, longitude, school.latitude, school.longitude, school.radius_meters
    )
    if not inside:
        raise HTTPException(
            status_code=403,
            detail=f"You are outside the school campus. You are approximately {int(distance)}m from campus (allowed radius: {school.radius_meters}m).",
        )

    today = date_type.today()
    existing = (
        db.query(Attendance)
        .filter(Attendance.teacher_id == teacher_id, Attendance.date == today)
        .first()
    )
    if existing and existing.check_in_time:
        raise HTTPException(status_code=400, detail="You have already checked in today.")

    now = datetime.now(timezone.utc)
    is_late = now.time() > school.school_start_time
    status = AttendanceStatus.late if is_late else AttendanceStatus.present

    if existing:
        existing.check_in_time = now
        existing.check_in_latitude = latitude
        existing.check_in_longitude = longitude
        existing.status = status
        record = existing
    else:
        record = Attendance(
            teacher_id=teacher_id,
            date=today,
            check_in_time=now,
            check_in_latitude=latitude,
            check_in_longitude=longitude,
            status=status,
        )
        db.add(record)

    db.commit()
    db.refresh(record)
    return record


def check_out(db: Session, teacher_id, latitude: float, longitude: float) -> Attendance:
    school = get_school_settings(db)

    inside, distance = is_within_geofence(
        latitude, longitude, school.latitude, school.longitude, school.radius_meters
    )
    if not inside:
        raise HTTPException(
            status_code=403,
            detail=f"You are outside the school campus. You are approximately {int(distance)}m from campus (allowed radius: {school.radius_meters}m).",
        )

    today = date_type.today()
    record = (
        db.query(Attendance)
        .filter(Attendance.teacher_id == teacher_id, Attendance.date == today)
        .first()
    )
    if not record or not record.check_in_time:
        raise HTTPException(status_code=400, detail="You must check in before checking out.")
    if record.check_out_time:
        raise HTTPException(status_code=400, detail="You have already checked out today.")

    now = datetime.now(timezone.utc)
    record.check_out_time = now
    record.check_out_latitude = latitude
    record.check_out_longitude = longitude
    record.working_hours = round((now - record.check_in_time).total_seconds() / 3600, 2)

    db.commit()
    db.refresh(record)
    return record
