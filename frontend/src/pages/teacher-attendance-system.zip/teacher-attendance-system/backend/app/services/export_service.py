"""
CSV / Excel export for attendance reports.
"""
import io
import pandas as pd


def build_dataframe(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows)


def to_csv_bytes(rows: list[dict]) -> bytes:
    df = build_dataframe(rows)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


def to_excel_bytes(rows: list[dict]) -> bytes:
    df = build_dataframe(rows)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Attendance")
    return buf.getvalue()
