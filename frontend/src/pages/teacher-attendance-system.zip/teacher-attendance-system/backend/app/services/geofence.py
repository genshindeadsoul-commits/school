"""
Geofencing: haversine distance between two GPS points, in meters.
"""
import math


def haversine_distance_meters(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two lat/lon points, in meters."""
    R = 6371000  # Earth radius in meters
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lon2 - lon1)

    a = (
        math.sin(d_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def is_within_geofence(lat: float, lon: float, school_lat: float, school_lon: float, radius_m: float) -> tuple[bool, float]:
    """Returns (is_inside, distance_in_meters)."""
    distance = haversine_distance_meters(lat, lon, school_lat, school_lon)
    return distance <= radius_m, distance
