"""
Seed script: creates the school_settings row (if missing), one admin account,
and a handful of sample teachers with a few days of sample attendance.

Run with:  python seed_data.py
(Run migrations/001_init.sql against your Supabase DB first.)
"""
import random
from datetime import date, datetime, timedelta, time, timezone

from app.database import SessionLocal, engine, Base
from app.models.teacher import Teacher, UserRole
from app.models.attendance import Attendance, AttendanceStatus
from app.models.settings import SchoolSettings
from app.utils.security import hash_password
from app.config import settings

Base.metadata.create_all(bind=engine)  # no-op if tables already exist via SQL migration

db = SessionLocal()

# --- School settings ---
if not db.query(SchoolSettings).filter(SchoolSettings.id == 1).first():
    db.add(SchoolSettings(
        id=1,
        school_name=settings.DEFAULT_SCHOOL_NAME,
        latitude=settings.DEFAULT_SCHOOL_LAT,
        longitude=settings.DEFAULT_SCHOOL_LNG,
        radius_meters=settings.DEFAULT_GEOFENCE_RADIUS_METERS,
        school_start_time=time.fromisoformat(settings.DEFAULT_SCHOOL_START_TIME),
    ))
    db.commit()
    print("Created school_settings")

# --- Admin ---
if not db.query(Teacher).filter(Teacher.email == settings.ADMIN_EMAIL).first():
    db.add(Teacher(
        name="School Admin",
        email=settings.ADMIN_EMAIL,
        phone="9999999999",
        department="Administration",
        designation="Principal",
        password_hash=hash_password(settings.ADMIN_PASSWORD),
        role=UserRole.admin,
        is_active=True,
    ))
    db.commit()
    print(f"Created admin: {settings.ADMIN_EMAIL} / {settings.ADMIN_PASSWORD}")

# --- Sample teachers ---
sample_teachers = [
    ("Anita Sharma", "anita.sharma@school.edu", "Mathematics", "PGT"),
    ("Ravi Kumar", "ravi.kumar@school.edu", "Science", "TGT"),
    ("Priya Nair", "priya.nair@school.edu", "English", "PGT"),
    ("Suresh Patel", "suresh.patel@school.edu", "Social Studies", "TGT"),
    ("Meera Iyer", "meera.iyer@school.edu", "Computer Science", "PGT"),
]

created_teachers = []
for name, email, dept, desig in sample_teachers:
    existing = db.query(Teacher).filter(Teacher.email == email).first()
    if existing:
        created_teachers.append(existing)
        continue
    t = Teacher(
        name=name, email=email, phone="9876543210", department=dept, designation=desig,
        password_hash=hash_password("Teacher@123"), role=UserRole.teacher, is_active=True,
    )
    db.add(t)
    db.commit()
    db.refresh(t)
    created_teachers.append(t)
    print(f"Created teacher: {email} / Teacher@123")

# --- Sample attendance for the last 5 weekdays ---
school = db.query(SchoolSettings).filter(SchoolSettings.id == 1).first()
today = date.today()
days_added = 0
d = today
while days_added < 5:
    d -= timedelta(days=1)
    if d.weekday() >= 5:  # skip weekends
        continue
    days_added += 1
    for t in created_teachers:
        if db.query(Attendance).filter(Attendance.teacher_id == t.id, Attendance.date == d).first():
            continue
        is_absent = random.random() < 0.1
        if is_absent:
            db.add(Attendance(teacher_id=t.id, date=d, status=AttendanceStatus.absent))
            continue
        is_late = random.random() < 0.2
        check_in_hour, check_in_minute = (9, random.randint(0, 15)) if is_late else (8, random.randint(20, 44))
        check_in = datetime.combine(d, time(check_in_hour, check_in_minute), tzinfo=timezone.utc)
        check_out = check_in + timedelta(hours=random.uniform(6.5, 8))
        db.add(Attendance(
            teacher_id=t.id, date=d,
            check_in_time=check_in, check_out_time=check_out,
            working_hours=round((check_out - check_in).total_seconds() / 3600, 2),
            check_in_latitude=school.latitude, check_in_longitude=school.longitude,
            check_out_latitude=school.latitude, check_out_longitude=school.longitude,
            status=AttendanceStatus.late if is_late else AttendanceStatus.present,
        ))
db.commit()
print("Sample attendance seeded.")

db.close()
print("\nDone. Admin login: ", settings.ADMIN_EMAIL, "/", settings.ADMIN_PASSWORD)
