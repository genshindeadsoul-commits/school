/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef7f6',
          100: '#d3ebe8',
          200: '#a7d7d1',
          300: '#78bfb6',
          400: '#4aa89a',
          500: '#2f8d7f',
          600: '#237166',
          700: '#1c5952',
          800: '#164742',
          900: '#123a36',
        },
        ink: {
          900: '#0f1720',
          800: '#182233',
        },
      },
      fontFamily: {
        display: ['"Manrope"', 'sans-serif'],
        sans: ['"Inter"', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(15, 23, 32, 0.06), 0 1px 8px rgba(15, 23, 32, 0.04)',
      },
    },
  },
  plugins: [],
}
