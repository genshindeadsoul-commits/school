import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import ProtectedRoute from './components/common/ProtectedRoute'

import Login from './pages/Login'
import AdminDashboard from './pages/admin/AdminDashboard'
import Teachers from './pages/admin/Teachers'
import AttendanceReports from './pages/admin/AttendanceReports'
import SchoolSettings from './pages/admin/SchoolSettings'
import TeacherDashboard from './pages/teacher/TeacherDashboard'
import TeacherHistory from './pages/teacher/TeacherHistory'

export default function App() {
  const { isAuthenticated, user } = useAuth()

  return (
    <Routes>
      <Route
        path="/login"
        element={isAuthenticated ? <Navigate to={user.role === 'admin' ? '/admin' : '/teacher'} replace /> : <Login />}
      />

      {/* Admin routes */}
      <Route path="/admin" element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/teachers" element={<ProtectedRoute role="admin"><Teachers /></ProtectedRoute>} />
      <Route path="/admin/reports" element={<ProtectedRoute role="admin"><AttendanceReports /></ProtectedRoute>} />
      <Route path="/admin/settings" element={<ProtectedRoute role="admin"><SchoolSettings /></ProtectedRoute>} />

      {/* Teacher routes */}
      <Route path="/teacher" element={<ProtectedRoute role="teacher"><TeacherDashboard /></ProtectedRoute>} />
      <Route path="/teacher/history" element={<ProtectedRoute role="teacher"><TeacherHistory /></ProtectedRoute>} />

      <Route
        path="/"
        element={<Navigate to={isAuthenticated ? (user.role === 'admin' ? '/admin' : '/teacher') : '/login'} replace />}
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
