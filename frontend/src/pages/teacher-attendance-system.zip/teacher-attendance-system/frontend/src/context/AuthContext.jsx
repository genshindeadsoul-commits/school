import React, { createContext, useContext, useState } from 'react'
import { login as apiLogin } from '../api/auth'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('tas_user')
    return saved ? JSON.parse(saved) : null
  })

  const login = async (email, password) => {
    const data = await apiLogin(email, password)
    const userData = { id: data.teacher_id, name: data.name, role: data.role }
    localStorage.setItem('tas_token', data.access_token)
    localStorage.setItem('tas_user', JSON.stringify(userData))
    setUser(userData)
    return userData
  }

  const logout = () => {
    localStorage.removeItem('tas_token')
    localStorage.removeItem('tas_user')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
