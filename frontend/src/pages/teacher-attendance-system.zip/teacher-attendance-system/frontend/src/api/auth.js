import client from './client'

export const login = (email, password) =>
  client.post('/api/auth/login', { email, password }).then((r) => r.data)

export const getMe = () => client.get('/api/auth/me').then((r) => r.data)

export const changePassword = (old_password, new_password) =>
  client.post('/api/auth/change-password', { old_password, new_password }).then((r) => r.data)
