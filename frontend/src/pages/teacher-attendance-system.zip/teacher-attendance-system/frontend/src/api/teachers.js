import client from './client'

export const listTeachers = (params) =>
  client.get('/api/teachers', { params }).then((r) => r.data)

export const getTeacher = (id) => client.get(`/api/teachers/${id}`).then((r) => r.data)

export const createTeacher = (payload) =>
  client.post('/api/teachers', payload).then((r) => r.data)

export const updateTeacher = (id, payload) =>
  client.put(`/api/teachers/${id}`, payload).then((r) => r.data)

export const deleteTeacher = (id) => client.delete(`/api/teachers/${id}`)

export const setTeacherStatus = (id, is_active) =>
  client.patch(`/api/teachers/${id}/status`, null, { params: { is_active } }).then((r) => r.data)

export const resetTeacherPassword = (id, new_password) =>
  client.post(`/api/teachers/${id}/reset-password`, { new_password }).then((r) => r.data)
