import client from './client'

export const checkIn = (latitude, longitude) =>
  client.post('/api/attendance/check-in', { latitude, longitude }).then((r) => r.data)

export const checkOut = (latitude, longitude) =>
  client.post('/api/attendance/check-out', { latitude, longitude }).then((r) => r.data)

export const getTodayStatus = () => client.get('/api/attendance/today').then((r) => r.data)

export const getMyHistory = (params) =>
  client.get('/api/attendance/history', { params }).then((r) => r.data)
