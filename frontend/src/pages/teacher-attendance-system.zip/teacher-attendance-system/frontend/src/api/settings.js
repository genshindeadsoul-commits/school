import client from './client'

export const getSchoolSettings = () => client.get('/api/settings').then((r) => r.data)

export const updateSchoolSettings = (payload) =>
  client.put('/api/settings', payload).then((r) => r.data)
