import client from './client'

export const getTodayReport = () => client.get('/api/reports/today').then((r) => r.data)

export const getRangeReport = (params) =>
  client.get('/api/reports/range', { params }).then((r) => r.data)

export const getTeacherReport = (teacherId, params) =>
  client.get(`/api/reports/teacher/${teacherId}`, { params }).then((r) => r.data)

export const exportReport = async (params) => {
  const response = await client.get('/api/reports/export', { params, responseType: 'blob' })
  const contentDisposition = response.headers['content-disposition'] || ''
  const match = contentDisposition.match(/filename="?([^"]+)"?/)
  const filename = match ? match[1] : `attendance.${params.format === 'excel' ? 'xlsx' : 'csv'}`
  const url = window.URL.createObjectURL(new Blob([response.data]))
  const link = document.createElement('a')
  link.href = url
  link.setAttribute('download', filename)
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.URL.revokeObjectURL(url)
}
