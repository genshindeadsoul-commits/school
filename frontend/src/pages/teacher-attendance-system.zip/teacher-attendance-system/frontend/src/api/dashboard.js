import client from './client'

export const getAdminDashboard = () => client.get('/api/dashboard/admin').then((r) => r.data)
