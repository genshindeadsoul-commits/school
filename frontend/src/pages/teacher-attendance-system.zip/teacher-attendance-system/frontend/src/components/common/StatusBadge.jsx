import React from 'react'

const STYLES = {
  present: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
  late: 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
  absent: 'bg-rose-50 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300',
}

export default function StatusBadge({ status }) {
  if (!status) return <span className="badge bg-slate-100 text-slate-500">—</span>
  return <span className={`badge capitalize ${STYLES[status] || STYLES.absent}`}>{status}</span>
}
