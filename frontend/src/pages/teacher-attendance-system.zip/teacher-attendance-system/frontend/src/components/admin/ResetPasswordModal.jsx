import React, { useState } from 'react'
import toast from 'react-hot-toast'
import { X, Loader2 } from 'lucide-react'
import { resetTeacherPassword } from '../../api/teachers'

export default function ResetPasswordModal({ open, teacher, onClose }) {
  const [password, setPassword] = useState('')
  const [saving, setSaving] = useState(false)

  if (!open) return null

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      await resetTeacherPassword(teacher.id, password)
      toast.success(`Password reset for ${teacher.name}.`)
      setPassword('')
      onClose()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Could not reset password.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="card w-full max-w-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold text-lg">Reset Password</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-slate-100 dark:hover:bg-white/10"><X size={18} /></button>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Set a new password for {teacher?.name}.</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input required minLength={6} type="text" className="input" placeholder="New password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <div className="flex justify-end gap-3">
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving && <Loader2 size={16} className="animate-spin" />}
              Reset
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
