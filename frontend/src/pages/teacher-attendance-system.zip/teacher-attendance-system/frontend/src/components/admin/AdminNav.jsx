import React from 'react'
import { NavLink } from 'react-router-dom'
import { LayoutDashboard, Users, FileBarChart, Settings } from 'lucide-react'

const links = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/teachers', label: 'Teachers', icon: Users },
  { to: '/admin/reports', label: 'Reports', icon: FileBarChart },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
]

export default function AdminNav() {
  return (
    <nav className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-1 overflow-x-auto border-b border-slate-200/70 dark:border-white/10">
      {links.map(({ to, label, icon: Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          className={({ isActive }) =>
            `flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              isActive
                ? 'border-brand-600 text-brand-700 dark:text-brand-400'
                : 'border-transparent text-slate-500 hover:text-ink-900 dark:text-slate-400 dark:hover:text-white'
            }`
          }
        >
          <Icon size={16} />
          {label}
        </NavLink>
      ))}
    </nav>
  )
}
