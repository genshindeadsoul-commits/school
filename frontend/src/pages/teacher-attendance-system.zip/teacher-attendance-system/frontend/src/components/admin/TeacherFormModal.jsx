import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { X, Loader2 } from 'lucide-react'
import { createTeacher, updateTeacher } from '../../api/teachers'

const EMPTY = { name: '', email: '', phone: '', department: '', designation: '', password: '' }

export default function TeacherFormModal({ open, teacher, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)
  const isEdit = !!teacher

  useEffect(() => {
    if (teacher) {
      setForm({ ...EMPTY, ...teacher })
    } else {
      setForm(EMPTY)
    }
  }, [teacher, open])

  if (!open) return null

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      if (isEdit) {
        const { password, ...rest } = form
        await updateTeacher(teacher.id, rest)
        toast.success('Teacher updated.')
      } else {
        await createTeacher(form)
        toast.success('Teacher added.')
      }
      onSaved()
      onClose()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Could not save teacher.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="card w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold text-lg">{isEdit ? 'Edit Teacher' : 'Add Teacher'}</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-slate-100 dark:hover:bg-white/10"><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Full Name</label>
            <input required name="name" className="input" value={form.name} onChange={handleChange} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Email</label>
              <input required type="email" name="email" className="input" value={form.email} onChange={handleChange} />
            </div>
            <div>
              <label className="label">Phone</label>
              <input name="phone" className="input" value={form.phone || ''} onChange={handleChange} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Department</label>
              <input name="department" className="input" value={form.department || ''} onChange={handleChange} />
            </div>
            <div>
              <label className="label">Designation</label>
              <input name="designation" className="input" value={form.designation || ''} onChange={handleChange} />
            </div>
          </div>
          {!isEdit && (
            <div>
              <label className="label">Initial Password</label>
              <input required type="text" name="password" minLength={6} className="input" value={form.password} onChange={handleChange} />
            </div>
          )}
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving && <Loader2 size={16} className="animate-spin" />}
              {isEdit ? 'Save Changes' : 'Add Teacher'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
