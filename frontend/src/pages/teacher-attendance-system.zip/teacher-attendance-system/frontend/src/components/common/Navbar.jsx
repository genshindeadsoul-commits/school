import React from 'react'
import { useNavigate, NavLink } from 'react-router-dom'
import { Sun, Moon, LogOut, GraduationCap } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'
import { useTheme } from '../../context/ThemeContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const { dark, toggleTheme } = useTheme()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/70 dark:border-white/10 bg-white/90 dark:bg-ink-900/90 backdrop-blur">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-brand-600 flex items-center justify-center">
            <GraduationCap className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="font-display font-bold text-sm leading-tight">Attendance</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-tight">
              {user?.role === 'admin' ? 'Admin Console' : 'Teacher Portal'}
            </p>
          </div>
        </div>

        {user?.role === 'teacher' && (
          <nav className="hidden sm:flex items-center gap-1">
            <NavLink to="/teacher" end className={({ isActive }) => `px-3 py-1.5 rounded-lg text-sm font-medium ${isActive ? 'bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-300' : 'text-slate-500 hover:text-ink-900 dark:text-slate-400 dark:hover:text-white'}`}>
              Today
            </NavLink>
            <NavLink to="/teacher/history" className={({ isActive }) => `px-3 py-1.5 rounded-lg text-sm font-medium ${isActive ? 'bg-brand-50 text-brand-700 dark:bg-brand-900/40 dark:text-brand-300' : 'text-slate-500 hover:text-ink-900 dark:text-slate-400 dark:hover:text-white'}`}>
              History
            </NavLink>
          </nav>
        )}

        <div className="flex items-center gap-3">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 text-slate-600 dark:text-slate-300"
            aria-label="Toggle dark mode"
          >
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <div className="hidden sm:block text-right">
            <p className="text-sm font-medium">{user?.name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 capitalize">{user?.role}</p>
          </div>
          <button onClick={handleLogout} className="btn-secondary" aria-label="Log out">
            <LogOut size={16} />
            <span className="hidden sm:inline">Log out</span>
          </button>
        </div>
      </div>
    </header>
  )
}
