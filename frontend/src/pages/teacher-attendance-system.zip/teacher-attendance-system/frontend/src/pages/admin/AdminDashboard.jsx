import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { Users, UserCheck, UserX, Clock3, TrendingUp } from 'lucide-react'
import Navbar from '../../components/common/Navbar'
import AdminNav from '../../components/admin/AdminNav'
import StatCard from '../../components/common/StatCard'
import StatusBadge from '../../components/common/StatusBadge'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import { getAdminDashboard } from '../../api/dashboard'

export default function AdminDashboard() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getAdminDashboard()
      .then(setData)
      .catch(() => toast.error('Could not load dashboard.'))
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen">
      <Navbar />
      <AdminNav />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <h1 className="font-display text-2xl font-bold">Dashboard</h1>

        {loading ? (
          <div className="flex justify-center py-20"><LoadingSpinner size={32} /></div>
        ) : (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              <StatCard label="Total Teachers" value={data.total_teachers} icon={Users} accent="brand" />
              <StatCard label="Present Today" value={data.present_today} icon={UserCheck} accent="brand" />
              <StatCard label="Absent Today" value={data.absent_today} icon={UserX} accent="rose" />
              <StatCard label="Late Today" value={data.late_today} icon={Clock3} accent="amber" />
              <StatCard label="Attendance %" value={`${data.attendance_percentage}%`} icon={TrendingUp} accent="slate" />
            </div>

            <div className="card">
              <div className="px-5 py-4 border-b border-slate-100 dark:border-white/10">
                <h2 className="font-display font-bold">Recent Check-ins</h2>
              </div>
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-slate-400 text-left">
                  <tr>
                    <th className="px-5 py-3 font-medium">Teacher</th>
                    <th className="px-5 py-3 font-medium">Check In</th>
                    <th className="px-5 py-3 font-medium">Check Out</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-white/10">
                  {data.recent_checkins.length ? data.recent_checkins.map((r) => (
                    <tr key={r.id}>
                      <td className="px-5 py-3">{r.teacher_name}</td>
                      <td className="px-5 py-3">{r.check_in_time ? new Date(r.check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                      <td className="px-5 py-3">{r.check_out_time ? new Date(r.check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                      <td className="px-5 py-3"><StatusBadge status={r.status} /></td>
                    </tr>
                  )) : (
                    <tr><td colSpan={4} className="px-5 py-10 text-center text-slate-400">No check-ins yet today.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
