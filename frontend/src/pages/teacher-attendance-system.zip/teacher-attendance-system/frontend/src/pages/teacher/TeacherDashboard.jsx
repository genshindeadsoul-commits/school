import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { MapPin, LogIn, LogOut, Clock, CalendarCheck, Loader2 } from 'lucide-react'
import Navbar from '../../components/common/Navbar'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import StatusBadge from '../../components/common/StatusBadge'
import { useGeolocation } from '../../hooks/useGeolocation'
import { getTodayStatus, checkIn, checkOut } from '../../api/attendance'

function formatTime(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

export default function TeacherDashboard() {
  const [status, setStatus] = useState(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const { getPosition } = useGeolocation()

  const refresh = async () => {
    try {
      const data = await getTodayStatus()
      setStatus(data)
    } catch (err) {
      toast.error('Could not load today\'s status.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  const handleAction = async (action) => {
    setSubmitting(true)
    try {
      const pos = await getPosition()
      if (action === 'in') {
        await checkIn(pos.latitude, pos.longitude)
        toast.success('Checked in successfully!')
      } else {
        await checkOut(pos.latitude, pos.longitude)
        toast.success('Checked out successfully!')
      }
      await refresh()
    } catch (err) {
      const message = err.response?.data?.detail || err.message || 'Something went wrong.'
      toast.error(message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Today</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><LoadingSpinner size={32} /></div>
        ) : (
          <>
            <div className="card p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <CalendarCheck size={18} className="text-brand-600 dark:text-brand-400" />
                  <span className="font-medium">Status</span>
                </div>
                <StatusBadge status={status?.status} />
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="rounded-lg bg-slate-50 dark:bg-white/5 p-4">
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Check In</p>
                  <p className="text-lg font-display font-bold">{formatTime(status?.check_in_time)}</p>
                </div>
                <div className="rounded-lg bg-slate-50 dark:bg-white/5 p-4">
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">Check Out</p>
                  <p className="text-lg font-display font-bold">{formatTime(status?.check_out_time)}</p>
                </div>
              </div>

              {status?.working_hours != null && (
                <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 mb-6">
                  <Clock size={16} />
                  <span>{status.working_hours} hours worked today</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-xs text-slate-400 mb-4">
                <MapPin size={14} />
                <span>You must be within the school campus to check in or out.</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  className="btn-primary py-3"
                  disabled={submitting || status?.checked_in}
                  onClick={() => handleAction('in')}
                >
                  {submitting ? <Loader2 size={16} className="animate-spin" /> : <LogIn size={16} />}
                  Check In
                </button>
                <button
                  className="btn-secondary py-3"
                  disabled={submitting || !status?.checked_in || status?.checked_out}
                  onClick={() => handleAction('out')}
                >
                  {submitting ? <Loader2 size={16} className="animate-spin" /> : <LogOut size={16} />}
                  Check Out
                </button>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
