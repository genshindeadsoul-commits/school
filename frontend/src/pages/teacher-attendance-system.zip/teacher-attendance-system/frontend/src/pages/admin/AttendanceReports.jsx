import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { Download } from 'lucide-react'
import Navbar from '../../components/common/Navbar'
import AdminNav from '../../components/admin/AdminNav'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import StatusBadge from '../../components/common/StatusBadge'
import { listTeachers } from '../../api/teachers'
import { getRangeReport, exportReport } from '../../api/reports'

function todayISO() {
  return new Date().toISOString().slice(0, 10)
}
function monthStartISO() {
  const d = new Date()
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10)
}

export default function AttendanceReports() {
  const [startDate, setStartDate] = useState(monthStartISO())
  const [endDate, setEndDate] = useState(todayISO())
  const [teacherId, setTeacherId] = useState('')
  const [teachers, setTeachers] = useState([])
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [exporting, setExporting] = useState(false)

  useEffect(() => {
    listTeachers({ page_size: 200 }).then((r) => setTeachers(r.items)).catch(() => {})
  }, [])

  const fetchReport = () => {
    setLoading(true)
    getRangeReport({ start_date: startDate, end_date: endDate, teacher_id: teacherId || undefined, page_size: 200 })
      .then(setData)
      .catch(() => toast.error('Could not load report.'))
      .finally(() => setLoading(false))
  }

  useEffect(fetchReport, [startDate, endDate, teacherId])

  const handleExport = async (format) => {
    setExporting(true)
    try {
      await exportReport({ start_date: startDate, end_date: endDate, teacher_id: teacherId || undefined, format })
      toast.success('Export downloaded.')
    } catch {
      toast.error('Export failed.')
    } finally {
      setExporting(false)
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <AdminNav />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="font-display text-2xl font-bold">Attendance Reports</h1>
          <div className="flex gap-2">
            <button className="btn-secondary" disabled={exporting} onClick={() => handleExport('csv')}>
              <Download size={16} /> CSV
            </button>
            <button className="btn-secondary" disabled={exporting} onClick={() => handleExport('excel')}>
              <Download size={16} /> Excel
            </button>
          </div>
        </div>

        <div className="card p-4 flex flex-wrap items-end gap-4">
          <div>
            <label className="label">From</label>
            <input type="date" className="input" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div>
            <label className="label">To</label>
            <input type="date" className="input" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
          </div>
          <div className="min-w-[200px]">
            <label className="label">Teacher</label>
            <select className="input" value={teacherId} onChange={(e) => setTeacherId(e.target.value)}>
              <option value="">All Teachers</option>
              {teachers.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div className="flex gap-2">
            <button className="btn-secondary" onClick={() => { setStartDate(todayISO()); setEndDate(todayISO()) }}>Today</button>
            <button className="btn-secondary" onClick={() => { setStartDate(monthStartISO()); setEndDate(todayISO()) }}>This Month</button>
          </div>
        </div>

        <div className="card overflow-hidden">
          {loading ? (
            <div className="flex justify-center py-16"><LoadingSpinner size={28} /></div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-slate-400 text-left">
                <tr>
                  <th className="px-5 py-3 font-medium">Teacher</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Check In</th>
                  <th className="px-5 py-3 font-medium">Check Out</th>
                  <th className="px-5 py-3 font-medium">Hours</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/10">
                {data?.items.length ? data.items.map((r) => (
                  <tr key={r.id}>
                    <td className="px-5 py-3 font-medium">{r.teacher_name}</td>
                    <td className="px-5 py-3">{r.date}</td>
                    <td className="px-5 py-3">{r.check_in_time ? new Date(r.check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                    <td className="px-5 py-3">{r.check_out_time ? new Date(r.check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                    <td className="px-5 py-3">{r.working_hours ?? '—'}</td>
                    <td className="px-5 py-3"><StatusBadge status={r.status} /></td>
                  </tr>
                )) : (
                  <tr><td colSpan={6} className="px-5 py-10 text-center text-slate-400">No records for this range.</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </div>
  )
}
