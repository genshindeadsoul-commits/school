import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { Plus, Search, Pencil, Trash2, KeyRound, Power } from 'lucide-react'
import Navbar from '../../components/common/Navbar'
import AdminNav from '../../components/admin/AdminNav'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import Pagination from '../../components/common/Pagination'
import ConfirmDialog from '../../components/common/ConfirmDialog'
import TeacherFormModal from '../../components/admin/TeacherFormModal'
import ResetPasswordModal from '../../components/admin/ResetPasswordModal'
import { listTeachers, deleteTeacher, setTeacherStatus } from '../../api/teachers'

export default function Teachers() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)

  const [formOpen, setFormOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [resetTarget, setResetTarget] = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)

  const fetchTeachers = () => {
    setLoading(true)
    listTeachers({ search: search || undefined, page, page_size: 10 })
      .then(setData)
      .catch(() => toast.error('Could not load teachers.'))
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    const t = setTimeout(fetchTeachers, 300)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, page])

  const handleToggleStatus = async (teacher) => {
    try {
      await setTeacherStatus(teacher.id, !teacher.is_active)
      toast.success(`${teacher.name} ${teacher.is_active ? 'deactivated' : 'activated'}.`)
      fetchTeachers()
    } catch {
      toast.error('Could not update status.')
    }
  }

  const handleDelete = async () => {
    try {
      await deleteTeacher(deleteTarget.id)
      toast.success('Teacher deleted.')
      setDeleteTarget(null)
      fetchTeachers()
    } catch {
      toast.error('Could not delete teacher.')
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <AdminNav />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="font-display text-2xl font-bold">Teachers</h1>
          <button className="btn-primary" onClick={() => { setEditing(null); setFormOpen(true) }}>
            <Plus size={16} /> Add Teacher
          </button>
        </div>

        <div className="relative max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            className="input pl-9"
            placeholder="Search by name or email..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1) }}
          />
        </div>

        <div className="card overflow-hidden">
          {loading ? (
            <div className="flex justify-center py-16"><LoadingSpinner size={28} /></div>
          ) : (
            <>
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-slate-400 text-left">
                  <tr>
                    <th className="px-5 py-3 font-medium">Name</th>
                    <th className="px-5 py-3 font-medium">Email</th>
                    <th className="px-5 py-3 font-medium">Department</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-white/10">
                  {data?.items.length ? data.items.map((t) => (
                    <tr key={t.id}>
                      <td className="px-5 py-3 font-medium">{t.name}</td>
                      <td className="px-5 py-3 text-slate-500 dark:text-slate-400">{t.email}</td>
                      <td className="px-5 py-3">{t.department || '—'}</td>
                      <td className="px-5 py-3">
                        <span className={`badge ${t.is_active ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 dark:bg-white/10'}`}>
                          {t.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-1">
                          <button title="Edit" className="p-2 rounded hover:bg-slate-100 dark:hover:bg-white/10" onClick={() => { setEditing(t); setFormOpen(true) }}>
                            <Pencil size={15} />
                          </button>
                          <button title="Reset password" className="p-2 rounded hover:bg-slate-100 dark:hover:bg-white/10" onClick={() => setResetTarget(t)}>
                            <KeyRound size={15} />
                          </button>
                          <button title={t.is_active ? 'Deactivate' : 'Activate'} className="p-2 rounded hover:bg-slate-100 dark:hover:bg-white/10" onClick={() => handleToggleStatus(t)}>
                            <Power size={15} />
                          </button>
                          <button title="Delete" className="p-2 rounded hover:bg-rose-50 dark:hover:bg-rose-900/30 text-rose-600" onClick={() => setDeleteTarget(t)}>
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )) : (
                    <tr><td colSpan={5} className="px-5 py-10 text-center text-slate-400">No teachers found.</td></tr>
                  )}
                </tbody>
              </table>
              {data && <div className="px-5"><Pagination page={page} pageSize={data.page_size} total={data.total} onPageChange={setPage} /></div>}
            </>
          )}
        </div>
      </main>

      <TeacherFormModal open={formOpen} teacher={editing} onClose={() => setFormOpen(false)} onSaved={fetchTeachers} />
      <ResetPasswordModal open={!!resetTarget} teacher={resetTarget} onClose={() => setResetTarget(null)} />
      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete Teacher"
        message={`This will permanently delete ${deleteTarget?.name} and all their attendance records. This cannot be undone.`}
        confirmLabel="Delete"
        danger
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  )
}
