import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import Navbar from '../../components/common/Navbar'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import StatusBadge from '../../components/common/StatusBadge'
import { getMyHistory } from '../../api/attendance'

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']

export default function TeacherHistory() {
  const now = new Date()
  const [month, setMonth] = useState(now.getMonth() + 1)
  const [year, setYear] = useState(now.getFullYear())
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    getMyHistory({ month, year })
      .then(setData)
      .catch(() => toast.error('Could not load attendance history.'))
      .finally(() => setLoading(false))
  }, [month, year])

  const totalWorkingHours = data?.items.reduce((sum, r) => sum + (r.working_hours || 0), 0) || 0
  const presentDays = data?.items.filter((r) => r.status !== 'absent').length || 0

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="font-display text-2xl font-bold">Attendance History</h1>
          <div className="flex gap-2">
            <select className="input w-auto" value={month} onChange={(e) => setMonth(Number(e.target.value))}>
              {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
            </select>
            <select className="input w-auto" value={year} onChange={(e) => setYear(Number(e.target.value))}>
              {[year - 1, year, year + 1].map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="card p-4">
            <p className="text-2xl font-display font-bold">{presentDays}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Days present</p>
          </div>
          <div className="card p-4">
            <p className="text-2xl font-display font-bold">{totalWorkingHours.toFixed(1)}h</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Total working hours</p>
          </div>
        </div>

        <div className="card overflow-hidden">
          {loading ? (
            <div className="flex justify-center py-16"><LoadingSpinner size={28} /></div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-white/5 text-slate-500 dark:text-slate-400 text-left">
                <tr>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium">Check In</th>
                  <th className="px-4 py-3 font-medium">Check Out</th>
                  <th className="px-4 py-3 font-medium">Hours</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/10">
                {data?.items.length ? data.items.map((r) => (
                  <tr key={r.id}>
                    <td className="px-4 py-3">{r.date}</td>
                    <td className="px-4 py-3">{r.check_in_time ? new Date(r.check_in_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                    <td className="px-4 py-3">{r.check_out_time ? new Date(r.check_out_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}</td>
                    <td className="px-4 py-3">{r.working_hours ?? '—'}</td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                  </tr>
                )) : (
                  <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400">No records for this month.</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </div>
  )
}
