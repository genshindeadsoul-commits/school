import React, { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { Loader2, Save } from 'lucide-react'
import Navbar from '../../components/common/Navbar'
import AdminNav from '../../components/admin/AdminNav'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import { getSchoolSettings, updateSchoolSettings } from '../../api/settings'

export default function SchoolSettings() {
  const [form, setForm] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    getSchoolSettings()
      .then((data) => setForm({ ...data, school_start_time: data.school_start_time.slice(0, 5) }))
      .catch(() => toast.error('Could not load settings.'))
      .finally(() => setLoading(false))
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm({ ...form, [name]: name === 'latitude' || name === 'longitude' || name === 'radius_meters' ? Number(value) : value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      await updateSchoolSettings({ ...form, school_start_time: `${form.school_start_time}:00` })
      toast.success('Settings saved.')
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Could not save settings.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <AdminNav />
      <main className="max-w-2xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <h1 className="font-display text-2xl font-bold">School Settings</h1>
        {loading || !form ? (
          <div className="flex justify-center py-16"><LoadingSpinner size={28} /></div>
        ) : (
          <form onSubmit={handleSubmit} className="card p-6 space-y-4">
            <div>
              <label className="label">School Name</label>
              <input name="school_name" className="input" value={form.school_name} onChange={handleChange} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Latitude</label>
                <input name="latitude" type="number" step="any" className="input" value={form.latitude} onChange={handleChange} />
              </div>
              <div>
                <label className="label">Longitude</label>
                <input name="longitude" type="number" step="any" className="input" value={form.longitude} onChange={handleChange} />
              </div>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 -mt-2">
              Tip: open your school on Google Maps, right-click the exact spot, and copy the coordinates shown.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Geofence Radius (meters)</label>
                <input name="radius_meters" type="number" min={10} max={2000} className="input" value={form.radius_meters} onChange={handleChange} />
              </div>
              <div>
                <label className="label">School Start Time (for "late" status)</label>
                <input name="school_start_time" type="time" className="input" value={form.school_start_time} onChange={handleChange} />
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <button type="submit" disabled={saving} className="btn-primary">
                {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                Save Settings
              </button>
            </div>
          </form>
        )}
      </main>
    </div>
  )
}
