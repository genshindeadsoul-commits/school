import { useState, useCallback } from 'react'

/**
 * Wraps navigator.geolocation.getCurrentPosition in a promise-friendly hook.
 * Used by the teacher check-in/check-out flow to grab a fresh GPS fix.
 */
export function useGeolocation() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const getPosition = useCallback(() => {
    setLoading(true)
    setError(null)
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        const err = 'Geolocation is not supported by this browser.'
        setError(err)
        setLoading(false)
        reject(new Error(err))
        return
      }
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLoading(false)
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
          })
        },
        (err) => {
          setLoading(false)
          let message = 'Unable to get your location.'
          if (err.code === err.PERMISSION_DENIED) {
            message = 'Location permission denied. Please enable location access to check in.'
          } else if (err.code === err.TIMEOUT) {
            message = 'Location request timed out. Please try again.'
          }
          setError(message)
          reject(new Error(message))
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
      )
    })
  }, [])

  return { getPosition, loading, error }
}
