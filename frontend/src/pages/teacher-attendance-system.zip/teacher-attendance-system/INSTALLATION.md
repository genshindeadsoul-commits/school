# Installation Guide

## 1. Prerequisites

- Python 3.11+
- Node.js 18+ and npm
- A free [Supabase](https://supabase.com) account (for Postgres)
- Git (optional, for deployment)

## 2. Set up Supabase (Database)

1. Create a new project at [supabase.com](https://supabase.com).
2. Go to **Project Settings → Database → Connection string → URI**. Copy it — this is your `DATABASE_URL`. Use the **Session pooler** connection string if available (works better with SQLAlchemy from serverless/edge hosts).
3. Go to **SQL Editor**, paste the contents of `backend/migrations/001_init.sql`, and run it. This creates the `teachers`, `attendance`, and `school_settings` tables and inserts the default geofence row.

## 3. Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
```

Edit `.env`:
```
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@db.YOUR_PROJECT_REF.supabase.co:5432/postgres
JWT_SECRET_KEY=<generate with: python -c "import secrets; print(secrets.token_hex(32))">
FRONTEND_ORIGIN=http://localhost:5173
ADMIN_EMAIL=admin@school.edu
ADMIN_PASSWORD=Admin@12345
```

Seed the database (creates admin + 5 sample teachers + sample attendance):
```bash
python seed_data.py
```

Run the API:
```bash
uvicorn app.main:app --reload --port 8000
```

Visit `http://localhost:8000/docs` for interactive Swagger docs, and `http://localhost:8000/health` to confirm it's up.

## 4. Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
```

Edit `.env`:
```
VITE_API_BASE_URL=http://localhost:8000
```

Run the dev server:
```bash
npm run dev
```

Visit `http://localhost:5173`. Log in with the admin or sample teacher credentials from step 3.

## 5. Setting Your Real School Location

The system ships with the geofence pre-set to the coordinates from your Google Maps link (AECS Magnolia Maaruti Public School, 12.8845715, 77.5969675, 75m radius). To change it:

1. Log in as admin → **Settings**.
2. Update Latitude / Longitude (right-click your school on Google Maps → the coordinates appear at the top of the context menu — click to copy).
3. Set the radius (75–150m is typical for a single building; increase for larger campuses).
4. Set the school start time used to compute "Late" status.

## 6. Deployment

### Backend → Railway or Render
1. Push the `backend/` folder to a Git repo.
2. Create a new Web Service, point it at the repo/`backend` subdirectory.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. Add environment variables from your `.env` (use your Supabase `DATABASE_URL`, a strong `JWT_SECRET_KEY`, and set `FRONTEND_ORIGIN` to your deployed frontend URL).
6. Run `python seed_data.py` once via the platform's shell/console (or a one-off job) to create the admin account.

### Frontend → Vercel
1. Push `frontend/` to a Git repo (or the same repo, set root directory to `frontend`).
2. Framework preset: **Vite**.
3. Build command: `npm run build`, output directory: `dist`.
4. Add environment variable `VITE_API_BASE_URL` = your deployed backend URL.
5. Deploy.

### CORS
Make sure `FRONTEND_ORIGIN` in the backend `.env` matches your deployed frontend's exact URL (including `https://`), or check-in/login requests will be blocked by the browser.

## 6b. Alternative: Docker

Dockerfiles are included for both services (`backend/Dockerfile`, `frontend/Dockerfile`), plus a `docker-compose.yml` for local development. Railway and Render will also auto-detect `backend/Dockerfile` if you point them at the `backend` folder.

```bash
# from the project root, with backend/.env already filled in
docker compose up --build
```
This serves the API on `http://localhost:8000` and the built frontend on `http://localhost:5173`. Note this does not include a local Postgres — `DATABASE_URL` in `backend/.env` should still point at your Supabase project.

## 7. Troubleshooting

- **"You are outside the school campus" during local testing:** your laptop's Wi-Fi-based geolocation can be inaccurate by hundreds of meters. Test on a phone with GPS enabled, or temporarily increase the radius in Settings, or set your school's coordinates to match your current test location.
- **CORS errors in the browser console:** double-check `FRONTEND_ORIGIN` in the backend `.env` exactly matches the URL in your browser's address bar.
- **401 errors right after login:** confirm `JWT_SECRET_KEY` is set and hasn't changed between token issuance and validation (e.g. after a backend redeploy that rotates the secret, users need to log in again).
- **Database connection errors:** Supabase's direct connection can require IPv6; if your host doesn't support it, use the **Session pooler** connection string instead (shown in Supabase's connection dialog).
